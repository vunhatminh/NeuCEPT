#!/bin/bash

python main.py --mode base10
python main.py --mode base2
python main-distill.py --mode distill
